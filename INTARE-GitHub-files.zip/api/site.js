const ORIGIN = 'https://oejuyodijdjneersnnrz.supabase.co/storage/v1/object/public/intare-site/';
const PAGES = new Set(['index', 'club', 'subscriptions', 'coaching', 'aerobics', 'reviews', 'visit']);

module.exports = async function site(req, res) {
  const url = new URL(req.url || '/', 'https://intare.invalid');
  const value = req.query?.page ?? url.searchParams.get('page') ?? 'index';
  const page = typeof value === 'string' ? value : '';

  if (!PAGES.has(page)) {
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    return res.status(404).send('Page not found');
  }
  if (!['GET', 'HEAD'].includes(req.method)) {
    res.setHeader('Allow', 'GET, HEAD');
    return res.status(405).send('Method not allowed');
  }
  try {
    const upstream = await fetch(ORIGIN + page + '.html', {
      signal: AbortSignal.timeout(15000)
    });
    if (!upstream.ok) throw new Error('Content unavailable');
    const html = await upstream.text();
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=0, s-maxage=300, stale-while-revalidate=600');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    return res.status(200).send(req.method === 'HEAD' ? '' : html);
  } catch {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    return res.status(503).send('The club website is temporarily unavailable. Please call +250 799 539 996.');
  }
};
